package com.carlauncher.app.shortcuts

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import com.carlauncher.app.R

/** Accesos rápidos configurables. MUSIC es el botón de origen en la franja del reproductor. */
enum class Slot(val prefKey: String, val labelRes: Int) {
    NAV("nav", R.string.slot_nav),
    PHONE("phone", R.string.slot_phone),
    RADIO("radio", R.string.slot_radio),
    BLUETOOTH("bluetooth", R.string.slot_bluetooth),
    SETTINGS("settings", R.string.slot_settings),
    MUSIC("music", R.string.slot_music)
}

object Shortcuts {

    const val PKG_GOOGLE_MAPS = "com.google.android.apps.maps"
    const val PKG_YOUTUBE_MUSIC = "com.google.android.apps.youtube.music"

    private const val PREFS = "shortcuts"

    fun customPackage(ctx: Context, slot: Slot): String? =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(slot.prefKey, null)

    fun setCustomPackage(ctx: Context, slot: Slot, pkg: String?) {
        val editor = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        if (pkg == null) editor.remove(slot.prefKey) else editor.putString(slot.prefKey, pkg)
        editor.apply()
    }

    fun resetAll(ctx: Context) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }

    /** Nombre de la app elegida por el usuario para este acceso, o null si usa el valor predeterminado. */
    fun customLabel(ctx: Context, slot: Slot): String? {
        val pkg = customPackage(ctx, slot) ?: return null
        return try {
            val pm = ctx.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            null // app desinstalada u oculta: se usa el predeterminado
        }
    }

    /**
     * Abre el destino del acceso. Devuelve false si no se pudo abrir nada
     * (el llamador puede entonces ofrecer elegir una app).
     */
    fun launch(activity: Activity, slot: Slot): Boolean {
        val custom = customPackage(activity, slot)
        if (custom != null && launchPackage(activity, custom)) return true

        return when (slot) {
            Slot.NAV ->
                launchPackage(activity, PKG_GOOGLE_MAPS) ||
                    start(activity, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=")))

            Slot.PHONE -> start(activity, Intent(Intent.ACTION_DIAL))

            // No existe una forma estándar de abrir "la radio" del equipo: hay que elegir la app.
            Slot.RADIO -> false

            Slot.BLUETOOTH -> start(activity, Intent(Settings.ACTION_BLUETOOTH_SETTINGS))

            Slot.SETTINGS -> start(activity, Intent(Settings.ACTION_SETTINGS))

            Slot.MUSIC -> launchPackage(activity, PKG_YOUTUBE_MUSIC)
        }
    }

    fun launchPackage(ctx: Context, pkg: String): Boolean {
        val intent = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        return start(ctx, intent)
    }

    fun start(ctx: Context, intent: Intent): Boolean {
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            true
        } catch (e: ActivityNotFoundException) {
            false
        } catch (e: SecurityException) {
            false
        }
    }
}
