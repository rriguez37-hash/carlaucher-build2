package com.carlauncher.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.carlauncher.app.map.MapPanel
import com.carlauncher.app.media.MediaBridge
import com.carlauncher.app.shortcuts.Shortcuts
import com.carlauncher.app.shortcuts.Slot
import com.carlauncher.app.ui.AppPicker
import com.carlauncher.app.ui.DiagnosticsActivity

/**
 * Pantalla de inicio: mapa arriba, accesos a la derecha, reproductor abajo.
 *
 * Diseño deliberadamente simple: vistas nativas, sin librerías de UI, sin animaciones,
 * sin servicios propios en segundo plano. Los listeners de GPS y de medios solo viven
 * mientras la pantalla es visible.
 */
class MainActivity : Activity() {

    private lateinit var map: MapPanel
    private lateinit var media: MediaBridge

    private lateinit var imgCover: ImageView
    private lateinit var txtTitle: TextView
    private lateinit var txtArtist: TextView
    private lateinit var btnPlay: ImageButton

    private val slotLabels = LinkedHashMap<Slot, TextView?>()
    private var currentState: MediaBridge.MediaState? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imgCover = findViewById(R.id.img_cover)
        txtTitle = findViewById(R.id.txt_title)
        txtArtist = findViewById(R.id.txt_artist)
        btnPlay = findViewById(R.id.btn_play)

        map = MapPanel(this, findViewById(R.id.map_container))
        media = MediaBridge(this) { state -> renderMedia(state) }

        bindSlot(Slot.NAV, R.id.btn_nav, R.id.lbl_nav)
        bindSlot(Slot.PHONE, R.id.btn_phone, R.id.lbl_phone)
        bindSlot(Slot.RADIO, R.id.btn_radio, R.id.lbl_radio)
        bindSlot(Slot.BLUETOOTH, R.id.btn_bluetooth, R.id.lbl_bluetooth)
        bindSlot(Slot.SETTINGS, R.id.btn_settings, R.id.lbl_settings)
        bindSlot(Slot.MUSIC, R.id.btn_music_source, null)
        refreshLabels()

        findViewById<View>(R.id.btn_prev).setOnClickListener { media.previous() }
        btnPlay.setOnClickListener { media.playPause() }
        findViewById<View>(R.id.btn_next).setOnClickListener { media.next() }
        findViewById<View>(R.id.media_info).setOnClickListener { onMediaInfoClick() }

        findViewById<View>(R.id.btn_zoom_in).setOnClickListener { map.zoomIn() }
        findViewById<View>(R.id.btn_zoom_out).setOnClickListener { map.zoomOut() }
        findViewById<View>(R.id.btn_recenter).setOnClickListener { map.recenter() }
        findViewById<View>(R.id.btn_where_to).setOnClickListener { openSlot(Slot.NAV) }
        findViewById<View>(R.id.btn_more).setOnClickListener { showMoreMenu() }

        requestLocationOnce()
    }

    override fun onStart() {
        super.onStart()
        media.start()
    }

    override fun onResume() {
        super.onResume()
        map.onResume()
        if (hasLocationPermission()) map.enableLocation()
    }

    override fun onPause() {
        map.onPause()
        super.onPause()
    }

    override fun onStop() {
        media.stop()
        super.onStop()
    }

    override fun onDestroy() {
        map.onDestroy()
        super.onDestroy()
    }

    /** Un launcher no debe cerrarse con el botón Atrás. */
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Intencionalmente vacío.
    }

    // ---------------------------------------------------------------- accesos

    private fun bindSlot(slot: Slot, viewId: Int, labelId: Int?) {
        val view = findViewById<View>(viewId)
        view.setOnClickListener { openSlot(slot) }
        view.setOnLongClickListener {
            chooseApp(slot)
            true
        }
        slotLabels[slot] = labelId?.let { findViewById<TextView>(it) }
    }

    private fun refreshLabels() {
        for ((slot, label) in slotLabels) {
            label?.text = Shortcuts.customLabel(this, slot) ?: getString(slot.labelRes)
        }
    }

    private fun openSlot(slot: Slot) {
        if (!Shortcuts.launch(this, slot)) {
            toast(R.string.msg_choose_app)
            chooseApp(slot)
        }
    }

    private fun chooseApp(slot: Slot) {
        AppPicker.show(
            activity = this,
            title = getString(R.string.pick_app_for, getString(slot.labelRes)),
            resetLabel = getString(R.string.use_default),
            onReset = {
                Shortcuts.setCustomPackage(this, slot, null)
                refreshLabels()
            }
        ) { pkg ->
            Shortcuts.setCustomPackage(this, slot, pkg)
            refreshLabels()
        }
    }

    // ---------------------------------------------------------------- multimedia

    private fun renderMedia(state: MediaBridge.MediaState?) {
        currentState = state
        if (state == null) {
            showCover(null)
            if (media.isAccessGranted()) {
                txtTitle.setText(R.string.media_idle)
                txtArtist.setText(R.string.media_idle_hint)
            } else {
                txtTitle.setText(R.string.media_need_access)
                txtArtist.setText(R.string.media_need_access_hint)
            }
            btnPlay.setImageResource(R.drawable.ic_play)
            return
        }
        txtTitle.text = state.title ?: getString(R.string.media_unknown_title)
        txtArtist.text = state.artist ?: ""
        showCover(state.art)
        btnPlay.setImageResource(if (state.playing) R.drawable.ic_pause else R.drawable.ic_play)
    }

    private fun showCover(art: Bitmap?) {
        if (art != null) {
            imgCover.scaleType = ImageView.ScaleType.CENTER_CROP
            imgCover.setPadding(0, 0, 0, 0)
            imgCover.setImageBitmap(art)
        } else {
            val p = dp(16)
            imgCover.scaleType = ImageView.ScaleType.FIT_CENTER
            imgCover.setPadding(p, p, p, p)
            imgCover.setImageResource(R.drawable.ic_music)
        }
    }

    private fun onMediaInfoClick() {
        if (!media.isAccessGranted()) {
            openNotificationAccessSettings()
            return
        }
        val pkg = currentState?.packageName
        if (pkg != null && Shortcuts.launchPackage(this, pkg)) return
        openSlot(Slot.MUSIC)
    }

    private fun openNotificationAccessSettings() {
        if (!Shortcuts.start(this, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))) {
            toast(R.string.msg_notif_settings_missing)
        }
    }

    // ---------------------------------------------------------------- menú

    private fun showMoreMenu() {
        val items = arrayOf(
            getString(R.string.menu_all_apps),
            getString(R.string.menu_default_launcher),
            getString(R.string.menu_notif_access),
            getString(R.string.menu_location),
            getString(R.string.menu_diagnostics),
            getString(R.string.menu_reset_shortcuts)
        )
        AlertDialog.Builder(this, R.style.DarkDialog)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> AppPicker.show(this, getString(R.string.menu_all_apps)) { pkg ->
                        Shortcuts.launchPackage(this, pkg)
                    }
                    1 -> openHomeSettings()
                    2 -> openNotificationAccessSettings()
                    3 -> requestLocation()
                    4 -> startActivity(Intent(this, DiagnosticsActivity::class.java))
                    5 -> {
                        Shortcuts.resetAll(this)
                        refreshLabels()
                    }
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun openHomeSettings() {
        if (Shortcuts.start(this, Intent(Settings.ACTION_HOME_SETTINGS))) return
        // Plan B: lanzar el intent HOME hace que Android pregunte qué inicio usar ("Siempre"/"Solo una vez").
        toast(R.string.msg_home_chooser)
        Shortcuts.start(this, Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME))
    }

    // ---------------------------------------------------------------- ubicación

    private fun hasLocationPermission(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    /** Pide el permiso solo la primera vez, para no molestar en cada arranque del launcher. */
    private fun requestLocationOnce() {
        if (hasLocationPermission()) {
            map.enableLocation()
            return
        }
        val prefs = getSharedPreferences("launcher", MODE_PRIVATE)
        if (prefs.getBoolean(KEY_ASKED_LOCATION, false)) return
        prefs.edit().putBoolean(KEY_ASKED_LOCATION, true).apply()
        requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), REQ_LOCATION)
    }

    private fun requestLocation() {
        if (hasLocationPermission()) {
            toast(R.string.msg_location_ok)
        } else {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), REQ_LOCATION)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_LOCATION &&
            grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED
        ) {
            map.enableLocation()
        }
    }

    // ---------------------------------------------------------------- utilidades

    private fun toast(resId: Int) = Toast.makeText(this, resId, Toast.LENGTH_LONG).show()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private companion object {
        const val REQ_LOCATION = 1001
        const val KEY_ASKED_LOCATION = "asked_location"
    }
}
