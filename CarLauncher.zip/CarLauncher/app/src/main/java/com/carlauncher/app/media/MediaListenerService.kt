package com.carlauncher.app.media

import android.service.notification.NotificationListenerService

/**
 * Servicio intencionalmente vacío.
 *
 * Android solo permite leer las sesiones de medios activas de otras apps
 * (MediaSessionManager.getActiveSessions) a quien tenga habilitado un
 * NotificationListenerService. No procesamos notificaciones: este componente solo
 * sirve como "identidad" para ese permiso, que el usuario concede manualmente en
 * Ajustes > Acceso a notificaciones.
 */
class MediaListenerService : NotificationListenerService()
