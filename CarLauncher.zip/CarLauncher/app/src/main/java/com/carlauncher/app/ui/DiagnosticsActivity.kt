package com.carlauncher.app.ui

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.carlauncher.app.R
import com.carlauncher.app.media.MediaBridge
import com.carlauncher.app.shortcuts.Shortcuts

/**
 * Pantalla de diagnóstico: muestra qué ofrece realmente esta unidad (Google Play Services,
 * sesiones de medios, apps del fabricante, etc.) para poder asignar accesos y decidir
 * qué funciones opcionales son viables. Se puede copiar el informe y pegarlo en un mensaje.
 */
class DiagnosticsActivity : Activity() {

    private lateinit var report: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = dp(16)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF05080F.toInt())
            setPadding(pad, pad, pad, pad)
        }

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.addView(makeButton(R.string.diag_refresh) { render() })
        buttons.addView(makeButton(R.string.diag_copy) { copyReport() })
        buttons.addView(makeButton(R.string.diag_close) { finish() })

        report = TextView(this).apply {
            setTextColor(Color.WHITE)
            typeface = Typeface.MONOSPACE
            textSize = 14f
            setTextIsSelectable(true)
        }
        val scroll = ScrollView(this).apply { addView(report) }

        root.addView(buttons)
        root.addView(
            scroll,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            ).apply { topMargin = dp(8) }
        )
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun makeButton(labelRes: Int, action: () -> Unit): Button =
        Button(this).apply {
            setText(labelRes)
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(
                0, dp(56), 1f
            ).apply { marginEnd = dp(8) }
        }

    private fun render() {
        report.text = buildReport()
    }

    private fun copyReport() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("diagnostico", report.text))
        Toast.makeText(this, R.string.diag_copied, Toast.LENGTH_SHORT).show()
    }

    private fun buildReport(): String {
        val sb = StringBuilder()
        fun add(s: String = "") {
            sb.append(s).append('\n')
        }

        add("== Dispositivo ==")
        add("Fabricante: ${Build.MANUFACTURER}")
        add("Marca: ${Build.BRAND}")
        add("Modelo: ${Build.MODEL}")
        add("Dispositivo: ${Build.DEVICE}")
        add("Producto: ${Build.PRODUCT}")
        add("Hardware: ${Build.HARDWARE}")
        add("Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        add("Build: ${Build.DISPLAY}")
        add("ABIs: ${Build.SUPPORTED_ABIS.joinToString()}")

        val dm = resources.displayMetrics
        add(
            "Pantalla: ${dm.widthPixels}x${dm.heightPixels} px, ${dm.densityDpi} dpi, " +
                "${(dm.widthPixels / dm.density).toInt()}x${(dm.heightPixels / dm.density).toInt()} dp"
        )

        add()
        add("== Servicios de Google ==")
        add("Google Play Services: ${pkgVersion("com.google.android.gms")}")
        add("Google Play Store: ${pkgVersion("com.android.vending")}")
        add("Google Maps: ${pkgVersion(Shortcuts.PKG_GOOGLE_MAPS)}")
        add("YouTube Music: ${pkgVersion(Shortcuts.PKG_YOUTUBE_MUSIC)}")

        add()
        add("== Hardware declarado ==")
        add("GPS: ${feature(PackageManager.FEATURE_LOCATION_GPS)}")
        add("Bluetooth: ${feature(PackageManager.FEATURE_BLUETOOTH)}")
        add("Telefonía: ${feature(PackageManager.FEATURE_TELEPHONY)}")
        add("Wi-Fi: ${feature(PackageManager.FEATURE_WIFI)}")

        val media = MediaBridge(this) { }
        add()
        add("== Permisos del launcher ==")
        add("Acceso a notificaciones (música): ${if (media.isAccessGranted()) "SÍ" else "NO"}")
        val loc = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
        add("Ubicación: ${if (loc) "SÍ" else "NO"}")

        add()
        add("== Sesiones de medios activas ==")
        add("(Reproduce algo por Bluetooth o YouTube Music y pulsa Actualizar)")
        add(media.describeSessions())

        add()
        add("== Launcher de inicio ==")
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val def = packageManager.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)
            ?.activityInfo?.packageName
        add("Predeterminado: ${def ?: "ninguno / pregunta siempre"}")
        val homes = packageManager.queryIntentActivities(home, 0)
            .map { it.activityInfo.packageName }.distinct()
        add("Disponibles: ${homes.joinToString()}")

        add()
        add("== Posibles apps del equipo (radio, bluetooth, música...) ==")
        val keywords = listOf(
            "radio", "fm", "bluetooth", "blue", "bt", "music", "media",
            "car", "auto", "link", "mirror", "phone", "sound", "eq"
        )
        val matches = AppPicker.loadApps(this).filter { e ->
            !e.pkg.startsWith("com.google.") &&
                keywords.any { k -> e.pkg.lowercase().contains(k) || e.label.lowercase().contains(k) }
        }
        if (matches.isEmpty()) add("(ninguna)") else matches.forEach { add("${it.label} — ${it.pkg}") }

        add()
        add("== Todas las apps con icono ==")
        AppPicker.loadApps(this).forEach { add("${it.label} — ${it.pkg}") }

        return sb.toString()
    }

    private fun pkgVersion(pkg: String): String = try {
        "instalado, v" + (packageManager.getPackageInfo(pkg, 0).versionName ?: "?")
    } catch (e: Exception) {
        "NO instalado (o no visible)"
    }

    private fun feature(name: String): String =
        if (packageManager.hasSystemFeature(name)) "sí" else "no"

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
