package com.carlauncher.app.ui

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.ResolveInfo
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import com.carlauncher.app.R

/** Diálogo temporal para elegir una app instalada. Los iconos se cargan solo al mostrarse. */
object AppPicker {

    class Entry(val label: String, val pkg: String, val info: ResolveInfo)

    fun loadApps(ctx: Context): List<Entry> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != ctx.packageName }
            .map { Entry(it.loadLabel(pm).toString(), it.activityInfo.packageName, it) }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    fun show(
        activity: Activity,
        title: String,
        resetLabel: String? = null,
        onReset: (() -> Unit)? = null,
        onPick: (String) -> Unit
    ) {
        val apps = loadApps(activity)
        val builder = AlertDialog.Builder(activity, R.style.DarkDialog)
            .setTitle(title)
            .setAdapter(Adapter(activity, apps)) { _, which -> onPick(apps[which].pkg) }
            .setNegativeButton(R.string.cancel, null)
        if (resetLabel != null && onReset != null) {
            builder.setNeutralButton(resetLabel) { _, _ -> onReset() }
        }
        builder.show()
    }

    private class Adapter(
        private val activity: Activity,
        private val items: List<Entry>
    ) : BaseAdapter() {

        override fun getCount(): Int = items.size

        override fun getItem(position: Int): Any = items[position]

        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val view = convertView
                ?: LayoutInflater.from(activity).inflate(R.layout.item_app, parent, false)
            val entry = items[position]
            view.findViewById<ImageView>(R.id.item_icon)
                .setImageDrawable(entry.info.loadIcon(activity.packageManager))
            view.findViewById<TextView>(R.id.item_label).text = entry.label
            return view
        }
    }
}
