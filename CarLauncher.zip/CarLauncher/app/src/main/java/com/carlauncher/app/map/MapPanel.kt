package com.carlauncher.app.map

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.util.Log
import android.view.ViewGroup
import android.widget.FrameLayout
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay
import java.io.File

/**
 * Panel de mapa basado en OpenStreetMap (osmdroid).
 *
 * Google Maps NO se puede incrustar en una app de terceros sin Google Play Services y una clave
 * de API de pago; por eso el mapa embebido es OSM y Google Maps se abre como app aparte
 * (botón "¿A dónde?" / acceso de navegación).
 *
 * Este panel está aislado a propósito: si el equipo tiene Play Services, se podría sustituir
 * por el MapView del SDK de Google sin tocar el resto del launcher.
 *
 * Ahorro de recursos: el GPS y el dibujado solo están activos mientras la pantalla es visible.
 */
class MapPanel(
    private val activity: Activity,
    private val container: FrameLayout
) {

    private var mapView: MapView? = null
    private var locationOverlay: MyLocationNewOverlay? = null
    private var resumed = false

    init {
        try {
            configureOsmdroid()
            createMap()
        } catch (t: Throwable) {
            // Si el mapa falla, el resto del launcher debe seguir funcionando.
            Log.e(TAG, "No se pudo crear el mapa", t)
            mapView = null
        }
    }

    private fun configureOsmdroid() {
        val ctx = activity.applicationContext
        val conf = Configuration.getInstance()
        conf.load(ctx, ctx.getSharedPreferences("osmdroid", Activity.MODE_PRIVATE))
        // Política de uso de OSM: identificar la app con un User-Agent propio.
        conf.userAgentValue = ctx.packageName
        val base = File(ctx.cacheDir, "osmdroid").apply { mkdirs() }
        val tiles = File(base, "tiles").apply { mkdirs() }
        conf.osmdroidBasePath = base
        conf.osmdroidTileCache = tiles
        // Límite de caché en disco para no llenar el almacenamiento de la unidad.
        conf.tileFileSystemCacheMaxBytes = 100L * 1024 * 1024
        conf.tileFileSystemCacheTrimBytes = 80L * 1024 * 1024
    }

    private fun createMap() {
        val mv = MapView(activity)
        mv.setTileSource(TileSourceFactory.MAPNIK)
        mv.setMultiTouchControls(true)
        mv.setTilesScaledToDpi(true)
        mv.setMinZoomLevel(3.0)
        mv.setMaxZoomLevel(19.0)
        mv.setBackgroundColor(0xFF0D1420.toInt())
        mv.zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
        mv.controller.setZoom(15.0)
        // Centro inicial provisional (hasta tener posición GPS). Cámbialo si lo necesitas.
        mv.controller.setCenter(GeoPoint(INITIAL_LAT, INITIAL_LON))
        mv.overlayManager.tilesOverlay.setColorFilter(darkFilter())

        container.addView(
            mv, 0,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        mapView = mv
    }

    /** Convierte los mosaicos claros de OSM en un estilo oscuro azulado (sin descargar otro estilo). */
    private fun darkFilter(): ColorMatrixColorFilter {
        val desaturate = ColorMatrix().apply { setSaturation(0.25f) }
        val invert = ColorMatrix(
            floatArrayOf(
                -1f, 0f, 0f, 0f, 255f,
                0f, -1f, 0f, 0f, 255f,
                0f, 0f, -1f, 0f, 255f,
                0f, 0f, 0f, 1f, 0f
            )
        )
        val tint = ColorMatrix(
            floatArrayOf(
                0.45f, 0f, 0f, 0f, 0f,
                0f, 0.60f, 0f, 0f, 0f,
                0f, 0f, 0.90f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )
        )
        val result = ColorMatrix(desaturate)
        result.postConcat(invert)
        result.postConcat(tint)
        return ColorMatrixColorFilter(result)
    }

    /** Idempotente: se puede llamar tras conceder el permiso o en cada onResume. */
    fun enableLocation() {
        val mv = mapView ?: return
        if (activity.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) return
        if (locationOverlay == null) {
            val overlay = MyLocationNewOverlay(GpsMyLocationProvider(activity.applicationContext), mv)
            overlay.enableFollowLocation()
            mv.overlays.add(overlay)
            locationOverlay = overlay
        }
        if (resumed) locationOverlay?.enableMyLocation()
    }

    fun zoomIn() {
        mapView?.controller?.zoomIn()
    }

    fun zoomOut() {
        mapView?.controller?.zoomOut()
    }

    fun recenter() {
        val overlay = locationOverlay ?: return
        overlay.enableFollowLocation()
        overlay.myLocation?.let { mapView?.controller?.setCenter(it) }
    }

    fun onResume() {
        resumed = true
        mapView?.onResume()
        locationOverlay?.enableMyLocation()
    }

    fun onPause() {
        resumed = false
        locationOverlay?.disableMyLocation() // apaga el GPS cuando el launcher no está a la vista
        mapView?.onPause()
    }

    fun onDestroy() {
        mapView?.onDetach()
        mapView = null
        locationOverlay = null
    }

    private companion object {
        const val TAG = "MapPanel"
        const val INITIAL_LAT = 13.6929
        const val INITIAL_LON = -89.2182
    }
}
