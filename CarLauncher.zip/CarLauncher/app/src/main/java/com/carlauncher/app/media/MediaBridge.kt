package com.carlauncher.app.media

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.provider.Settings
import android.view.KeyEvent

/**
 * Puente hacia los reproductores de otras apps (YouTube Music, Bluetooth del equipo, etc.).
 *
 * - Con "Acceso a notificaciones" concedido: lee título/artista/carátula/estado de la sesión
 *   de medios activa y usa sus controles de transporte.
 * - Sin ese permiso, o sin sesión activa: los botones envían teclas multimedia al sistema
 *   (AudioManager.dispatchMediaKeyEvent), que Android enruta a la última app que reprodujo.
 *
 * Solo escucha mientras la pantalla es visible (start/stop desde onStart/onStop).
 */
class MediaBridge(
    context: Context,
    private val onChange: (MediaState?) -> Unit
) {

    data class MediaState(
        val packageName: String,
        val title: String?,
        val artist: String?,
        val art: Bitmap?,
        val playing: Boolean
    )

    private val appContext = context.applicationContext
    private val sessionManager =
        appContext.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
    private val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val listenerComponent = ComponentName(appContext, MediaListenerService::class.java)

    private var controller: MediaController? = null
    private var started = false

    // Caché de la última carátula reducida, para no reescalar en cada cambio de estado.
    private var lastArtSource: Bitmap? = null
    private var lastArtScaled: Bitmap? = null

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> selectController(list) }

    private val controllerCallback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) {
            publish()
        }

        override fun onMetadataChanged(metadata: MediaMetadata?) {
            publish()
        }

        override fun onSessionDestroyed() {
            refresh()
        }
    }

    /** ¿Está concedido el acceso a notificaciones para este launcher? */
    fun isAccessGranted(): Boolean {
        val flat = Settings.Secure.getString(
            appContext.contentResolver, "enabled_notification_listeners"
        ) ?: return false
        return flat.split(":").any {
            ComponentName.unflattenFromString(it)?.packageName == appContext.packageName
        }
    }

    fun start() {
        if (started) return
        if (!isAccessGranted()) {
            onChange(null)
            return
        }
        try {
            sessionManager.addOnActiveSessionsChangedListener(sessionsListener, listenerComponent)
            started = true
            refresh()
        } catch (e: SecurityException) {
            onChange(null)
        }
    }

    fun stop() {
        if (!started) return
        try {
            sessionManager.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (e: Exception) {
            // Nada que hacer: ya no estamos escuchando.
        }
        controller?.unregisterCallback(controllerCallback)
        controller = null
        started = false
    }

    private fun refresh() {
        try {
            selectController(sessionManager.getActiveSessions(listenerComponent))
        } catch (e: SecurityException) {
            onChange(null)
        }
    }

    private fun selectController(list: List<MediaController>?) {
        val best = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list?.firstOrNull()
        val old = controller
        if (best?.sessionToken != old?.sessionToken) {
            old?.unregisterCallback(controllerCallback)
            controller = best
            best?.registerCallback(controllerCallback)
        }
        publish()
    }

    private fun publish() {
        val c = controller
        if (c == null) {
            onChange(null)
            return
        }
        val md = c.metadata
        val title = md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
            ?: md?.getString(MediaMetadata.METADATA_KEY_TITLE)
        val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
        val art = downscale(
            md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: md?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        )
        val playing = c.playbackState?.state == PlaybackState.STATE_PLAYING
        onChange(MediaState(c.packageName, title, artist, art, playing))
    }

    private fun downscale(src: Bitmap?): Bitmap? {
        if (src == null || src.isRecycled) return null
        if (src === lastArtSource) return lastArtScaled
        val maxSide = 384
        val side = maxOf(src.width, src.height)
        val result = if (side <= maxSide) {
            src
        } else {
            val scale = maxSide.toFloat() / side
            Bitmap.createScaledBitmap(
                src,
                (src.width * scale).toInt().coerceAtLeast(1),
                (src.height * scale).toInt().coerceAtLeast(1),
                true
            )
        }
        lastArtSource = src
        lastArtScaled = result
        return result
    }

    // ---- Controles ----

    fun previous() {
        val tc = controller?.transportControls
        if (tc != null) tc.skipToPrevious() else sendKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
    }

    fun next() {
        val tc = controller?.transportControls
        if (tc != null) tc.skipToNext() else sendKey(KeyEvent.KEYCODE_MEDIA_NEXT)
    }

    fun playPause() {
        val c = controller
        if (c != null) {
            if (c.playbackState?.state == PlaybackState.STATE_PLAYING) {
                c.transportControls.pause()
            } else {
                c.transportControls.play()
            }
        } else {
            sendKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
        }
    }

    private fun sendKey(code: Int) {
        audioManager.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        audioManager.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    // ---- Diagnóstico ----

    fun describeSessions(): String {
        if (!isAccessGranted()) {
            return "Sin acceso a notificaciones: no se pueden listar las sesiones de medios."
        }
        return try {
            val list = sessionManager.getActiveSessions(listenerComponent)
            if (list.isEmpty()) {
                "Ninguna sesión de medios activa."
            } else {
                list.joinToString("\n") { c ->
                    "${c.packageName} | estado=${c.playbackState?.state} | " +
                        "${c.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)}"
                }
            }
        } catch (e: SecurityException) {
            "Error de permisos al leer sesiones: ${e.message}"
        }
    }
}
