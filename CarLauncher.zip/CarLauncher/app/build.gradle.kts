plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.carlauncher.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.carlauncher.app"
        minSdk = 26
        // Se apunta a Android 11 (API 30), que es lo que declara el equipo.
        targetSdk = 30
        versionCode = 1
        versionName = "0.1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            // Solo para pruebas personales: firma con la clave de depuración para que el APK
            // release sea instalable. Para distribuir, usa tu propio keystore.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    // Única dependencia externa: mapa OpenStreetMap sin clave de API ni Google Play Services.
    // No se usa AppCompat/Compose/Material a propósito, para minimizar memoria y arranque.
    implementation("org.osmdroid:osmdroid-android:6.1.18")
}
